/***************************************************
* FILE NAME: selfdel.c
*
* PURPOSE:
*    NSIS plug-in for self deleting uninstaller for
*    Win9x/WinNT (all versions)
*
* CONSIDERATIONS
* 
*	MSVC6: works with Release built only, because source
*  file must be compiled with /GZ turned OFF, but in
*  Debug builds it is always on (basically, disable 
*  run-time stack checks)
*
* CHANGE HISTORY
*
* Author              Date          Modifications
* J Brown             1/10/2003     Original
*        http://www.catch22.net/tuts/selfdel.asp
* Takhir Bedertdinov  Jan  21 2006  Converted to NSIS 
*        plug-in, rmdir implementation, MSVCRT 
*        dependencies removed
**************************************************/

#include <windows.h>
#include <tchar.h>
#include "..\ExDll\exdll.h"

#pragma pack(push, 1)

#define CODESIZE 0x200
#define RMDIR "/RMDIR"

//
//	Structure to inject into remote process. Contains 
//  function pointers and code to execute.
//
typedef struct _SELFDEL
{
	struct _SELFDEL *Arg0;			// pointer to self

	BYTE	opCodes[CODESIZE];		// code 

	HANDLE	hParent;				// parent process handle

	FARPROC	fnWaitForSingleObject;
	FARPROC	fnCloseHandle;
	FARPROC	fnDeleteFile;
	FARPROC	fnSleep;
	FARPROC	fnExitProcess;
	FARPROC fnRemoveDirectory;
	FARPROC fnGetLastError;

	BOOL	fRemDir;

	TCHAR	szFileName[MAX_PATH];	// file to delete

} SELFDEL;

#pragma pack(pop)

#ifdef _DEBUG
#define FUNC_ADDR(func) (PVOID)(*(DWORD *)((BYTE *)func + 1) + (DWORD)((BYTE *)func + 5))
#else
#define FUNC_ADDR(func) func
#endif

/*****************************************************
 * FUNCTION NAME: remote_thread()
 * PURPOSE: 
 *    Routine to execute in remote process
 * SPECIAL CONSIDERATIONS:
 *    Takhir: I hope it still less then CODESIZE after 
 *    I added rmdir
 *****************************************************/
static void remote_thread(SELFDEL *remote)
{
   char *p = remote->szFileName, *e;
	// wait for parent process to terminate
	remote->fnWaitForSingleObject(remote->hParent, INFINITE);
	remote->fnCloseHandle(remote->hParent);

	// try to delete the executable file 
	while(!remote->fnDeleteFile(remote->szFileName))
	{
		// failed - try again in one second's time
		remote->fnSleep(1000);
	}
// Takhir: my rmdir add-on :)
// we nave at least one back slash in full path-name
// strrchr() implementation
   if(remote->fRemDir)
   {
      while(*++p != 0)
      {
         if(*p == '\\')
            e = p;
      }
      *e = 0;
// root install safe, rmdir on Wins not deletes 'c:'
      remote->fnRemoveDirectory(remote->szFileName);
   }

// finished! exit so that we don't execute garbage code
	remote->fnExitProcess(0);
}

/*****************************************************
 * FUNCTION NAME: my_memcpy()
 * PURPOSE: 
 *    msvcrt replacement
 * SPECIAL CONSIDERATIONS:
 *    
 *****************************************************/
void my_memcpy(BYTE* dst, BYTE* src, int len)
{
   int i;
   for(i=0;i<len;i++)
      dst[i] = src[i];
}

/*****************************************************
 * FUNCTION NAME: selfdel()
 * PURPOSE: 
 *    Delete currently running executable and exit
 * SPECIAL CONSIDERATIONS:
 *    
 *****************************************************/
void __declspec(dllexport) del(HWND hwndParent,
                                int string_size,
                                char *variables,
                                stack_t **stacktop)
{
	STARTUPINFO			si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	CONTEXT				context;
	DWORD				oldProt;
	SELFDEL				local;
	DWORD				entrypoint;
	TCHAR				szExe[MAX_PATH] = _T("explorer.exe");
   TCHAR          *s = GlobalAlloc(GPTR, string_size);

   EXDLL_INIT();
   local.fRemDir = FALSE;
   if(popstring(s) == 0)
   {
      if(lstrcmpi(s, RMDIR) == 0)
         local.fRemDir = TRUE;
      else pushstring(s); // who forgot this string in the stack ? :)
   }
   GlobalFree(s);

   //
	//	Create executable suspended
	//
	if(CreateProcess(0, szExe, 0, 0, 0, CREATE_SUSPENDED|IDLE_PRIORITY_CLASS, 0, 0, &si, &pi))
	{
		local.fnWaitForSingleObject		= (FARPROC)WaitForSingleObject;
		local.fnCloseHandle				= (FARPROC)CloseHandle;
		local.fnDeleteFile				= (FARPROC)DeleteFile;
		local.fnSleep					= (FARPROC)Sleep;
		local.fnExitProcess				= (FARPROC)ExitProcess;
		local.fnRemoveDirectory			= (FARPROC)RemoveDirectory;
		local.fnGetLastError			= (FARPROC)GetLastError;

		// Give remote process a copy of our own process handle
		DuplicateHandle(GetCurrentProcess(), GetCurrentProcess(), 
			pi.hProcess, &local.hParent, 0, FALSE, 0);

		GetModuleFileName(NULL, local.szFileName, MAX_PATH);

		// copy in binary code
      my_memcpy(local.opCodes, (BYTE*)FUNC_ADDR(remote_thread), CODESIZE);
//      memcpy(local.opCodes, FUNC_ADDR(remote_thread), CODESIZE);

		//
		// Allocate some space on process's stack and place
		// our SELFDEL structure there. Then set the instruction pointer 
		// to this location and let the process resume
		//
		context.ContextFlags = CONTEXT_INTEGER|CONTEXT_CONTROL;
		GetThreadContext(pi.hThread, &context);

		// Allocate space on stack (aligned to cache-line boundary)
		entrypoint = (context.Esp - sizeof(SELFDEL)) & ~0x1F;
		
		//
		// Place a pointer to the structure at the bottom-of-stack 
		// this pointer is located in such a way that it becomes 
		// the remote_thread's first argument!!
		//
		local.Arg0 = (SELFDEL *)entrypoint;

		context.Esp = entrypoint - 4;	// create dummy return address
		context.Eip = entrypoint + 4;	// offset of opCodes within structure

		// copy in our code+data at the exe's entry-point
		VirtualProtectEx(pi.hProcess,   (PVOID)entrypoint, sizeof(local), PAGE_EXECUTE_READWRITE, &oldProt);
		WriteProcessMemory(pi.hProcess, (PVOID)entrypoint, &local, sizeof(local), 0);

		FlushInstructionCache(pi.hProcess, (PVOID)entrypoint, sizeof(local));

		SetThreadContext(pi.hThread, &context);

		// Let the process continue
		ResumeThread(pi.hThread);
		CloseHandle(pi.hThread);
		CloseHandle(pi.hProcess);

		pushstring("OK");
	}

		pushstring("FAILED");
}

/*****************************************************
 * FUNCTION NAME: DllMain()
 * PURPOSE: 
 *    Dll main entry point
 * SPECIAL CONSIDERATIONS:
 *    
 *****************************************************/
BOOL WINAPI DllMain(HANDLE hInst,
						  ULONG ul_reason_for_call,
						  LPVOID lpReserved)
{
	return TRUE;
}
